resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a5811d8f9'

client_scripts{
	'Config.lua',
	'cl-vape.lua'
}

server_scripts{
	'Config.lua',
	'sv-vape.lua'
}